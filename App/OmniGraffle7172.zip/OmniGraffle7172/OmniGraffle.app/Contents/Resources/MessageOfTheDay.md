---
iconImage: images/OmniGraffle.png
appName: OmniGraffle
marketingName: OmniGraffle
platform: Mac
subheading: Release Notes: What's new, updated, or fixed
feedbackEmail: omnigraffle@omnigroup.com
archive: http://www.omnigroup.com/products/omnigraffle/download/releasenotes/
svn-header: $Header$
test: false
key_html: <div class="key"><ul><li class="new">New</li><li class="updated">Updated</li><li class="fixed">Fixed</li></ul></div>
---

## Recent Changes

### {class:key} Version 7.17.2

- fixed - **Connected Lines** --- Manipulating a multiple selection of objects redraws the position of any connected lines that are part of the selection when resizing or rotating.
- fixed - **Licensing** --- Open documents become editable when the app is unlocked and exits Free Reader Mode.
- fixed - **Export Panel** --- The format selection button area of the Export panel has been changed to fix layout issues when running a beta OS.

### {class:key} Version 7.17.1

- updated - **File Formats** --- When changing file format types, a copy of the original is placed in the Trash as a recovery backup. 
- fixed - **Data Corruption** --- Finder Tags are retained when upgrading the file format.
- fixed - **Lines** --- Fixed a bug with midpoints sometimes being added between the wrong two points on the line.
- fixed - **Variables** --- Variables in a table, subgraph, or group on a Shared Layer show correct values on each page when printed.
- fixed - **SVG Import** --- Improved SVG import for a number of situations.
- fixed - **SVG Export** --- Improved conformance to the SVG DTD. 
- fixed - **Image Masks** --- Image position does not change when resizing the mask for rotating shapes and certain PDFs.
- fixed - **AppleScript** --- New documents created with AppleScript are in the latest file format.
- fixed - **Resources** --- The **File > New Resource** options create documents in the latest format.
- fixed - **Groups** --- Fixed a bug with resizing groups that contains lines.
- fixed - **Groups** --- Fixed a bug with connected lines not rotating along with the rest of the group correctly.
- fixed - **Trials** --- Improved behavior on final day of trial. 
- fixed - **Crash Reporting** --- OmniGraffle crash reports can now be submitted on a Mac running a beta OS.
- fixed - **Stability** --- Accessing the purchase menu item or interacting with the first run window no longer crashes on Macs running a beta OS.


### {class:key} Version 7.17

- new - **Personal Subscriptions** --- OmniGraffle now has support for (optional) subscriptions! Subscriptions give you the latest version of the app, enabling every feature on every platform (including Pro features)—with a lower cost up front and predictable spending in the future. (If you prefer the traditional licensing model, that option also remains available: traditional licenses are investments which cost more up front, but save money in the long run.)
- new - **Unified Trials** --- We're unifying our trials to use a single, simple approach: you sign up for a trial, it lasts for two weeks, and then it ends without charging you.
- fixed - **Images** --- Fixed a bug that caused the rendering of some images on the canvas to fail when the document is opened.
- fixed - **SVG Import** --- Fixed multiple SVG importing bugs.
- fixed - **Stability** --- Fixed a crash that could occur when undoing the deletion of objects with **Auto layout** active.
- fixed - **Stability** --- Fixed a crash that would most commonly occur when duplicating a file.