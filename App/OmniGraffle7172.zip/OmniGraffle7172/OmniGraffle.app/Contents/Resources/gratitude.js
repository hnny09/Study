targetWidth = 590;
targetHeight = 260;
hero.minWidth = targetWidth;
hero.maxWidth = targetWidth;
hero.minHeight = targetHeight;
hero.maxHeight = targetHeight;
hero.preventScrolling();
hero.runModalAsynchronously();

function setDisplayStyleOnNodesOfClass(className, displayStyle) {
    var buildDetailsNodeList = document.getElementsByClassName(className);
    for (var elementIndex=0; elementIndex < buildDetailsNodeList.length; elementIndex++) {
        var buildDetailsElement = buildDetailsNodeList[elementIndex];
        var style = buildDetailsElement.style;
        style.display = displayStyle;
    }
}

function gratitudeOnLoad()
{
    if (hero.isAppStoreEdition()) {
        setDisplayStyleOnNodesOfClass("MacAppStoreOnly", "inline");
    } else {
        setDisplayStyleOnNodesOfClass("OmniStoreOnly", "inline");
    }

    if (hero.isProUnlocked()) {
        setDisplayStyleOnNodesOfClass("ProOnly", "inline");
    }

    if (!hero.isInTrialMode()) {
        setDisplayStyleOnNodesOfClass("PurchasedOnly", "inline");
    }
    
    if (hero.hasDarkAppearance()) {
        document.body.classList.add('dark-mode');
    } else {
        document.body.classList.remove('dark-mode');
    }

}
