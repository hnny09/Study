// Copyright 2016 Omni Development, Inc. All rights reserved.
//
// This software may only be used and reproduced according to the
// terms in the file OmniSourceLicense.html, which should be
// distributed with this project and can also be found at
// <http://www.omnigroup.com/developer/sourcecode/sourcelicense/>.
//
// $Header$
//
// In the spirit of Luc125's answer at http://stackoverflow.com/questions/6209161/extract-the-current-dom-and-print-it-as-a-string-with-styles-intact

(function (topElement) {
    var defaultStylesByTagName = {};
    var skipStyleTags = {"svg":true,"style":true};
    var targetStyles = ["fill", "fill-opacity", "stroke", "stroke-width", "stroke-linecap", "stop-color", "stop-opacity", "font-style", "font-variant", "font-weight", "font-size", "line-height", "font-family", "text-anchor"];

    function computeDefaultStyleByTagName(tagName) {
        var defaultStyle = {};
        var element = document.rootElement.appendChild(document.createElement(tagName));
        var computedStyle = getComputedStyle(element);
        for (var styleIndex = 0; styleIndex < computedStyle.length; styleIndex++) {
            defaultStyle[computedStyle[styleIndex]] = computedStyle[computedStyle[styleIndex]];
        }
        document.rootElement.removeChild(element); 
        return defaultStyle;
    }

    function getDefaultStyleByTagName(tagName) {
        if (!defaultStylesByTagName[tagName]) {
            defaultStylesByTagName[tagName] = computeDefaultStyleByTagName(tagName);
        }
        return defaultStylesByTagName[tagName];
    }

    var elements = topElement.querySelectorAll("*");
    for (var elementIndex = 0; elementIndex < elements.length; elementIndex++) {
        var styledElement = elements[elementIndex];
        var tagName = styledElement.tagName.toLowerCase()
        if (skipStyleTags[tagName]) {
            continue;
        }

        var computedStyle = getComputedStyle(styledElement);
        var defaultStyle = getDefaultStyleByTagName(tagName);
        for (var styleIndex = 0; styleIndex < targetStyles.length; styleIndex++) {
            var targetStyle = targetStyles[styleIndex];
            if (computedStyle[targetStyle] !== defaultStyle[targetStyle]) {
                styledElement.setAttribute(targetStyle, computedStyle[targetStyle]);
            }
        }
    }
    return topElement.outerHTML;

})(document.rootElement);
