<h2 id="recent">Recent Changes</h2>

<!-- Put items in the same order as the key: danger, new, updated, fixed -->  

### May 15, 2020 ###
- new - **Documentation** --- The documentation display on macOS and iOS now has field to filter based on a search term.

### May 13, 2020 ###
- updated - **Console** --- When a script command results in an error, highlight the backgound of the line causing it in the error color.

### May 12, 2020 ###
- updated - **Documentation** --- Improved the documentation style sheet.

### May 11, 2020 ###
- updated - **Object Properties** --- Updated how we bind instance properties so that `Object.getOwnPropertyNames(nativeObject)` will report the expected property names.
- updated - **Console** --- Updated the Console formatting to show properties for result objects in a more usable form.
- updated - **Console** --- Updated the Console to include `$N` variables for previous results.

### May 1, 2020 ###
- updated - **Pasteboard** --- Renamed the `FileType` class to `TypeIdentifier` (but left a backwards compatiblity name around for now).
- new - **Pasteboard** --- Added basic support for getting and setting content on the pasteboard.

### April 30, 2020 ###
- updated - **Callback** --- Tweaked the `x-callback` change from yesterday to be more backward compatible. On success, if the reply URL has a single parameter, that is elevated to the first argument to the success function. The success function is also now passed a second argument that is the full object of parameters from the reply URL. The error object remains a full object of parameters from the reply URL.

### April 29, 2020 ###
- updated - **Callback** --- Updated the `x-callback` support in `URL.call()` to properly return all parameters passed to the `x-success` or `x-error` return URLs. Previously the `result` or `errorMessage` were the only parameters returned, but now a full Object will be passed with properties for each returned parameter. This may break existing scripts, but hopefully very few were depending on this broken behavior.

### April 23, 2020 ###
- new - **API** --- Added a `currencyCode` property to `Locale`.
- new - **Formatters** --- Expose support for string formatting through `Formatter` classes. These may be applied to `Form.Field.String` and `Form.Field.Date` instances to have the former parse strings into dates, numbers, and durations, and the later just format dates. Both of these field classes also now provide a `keyboardType` property (only on iOS) to aid in inputting values for their type. The default for `keyboardType` will be set by the choice of formatter, but can be changed before the containing form is shown.

### April 16, 2020 ###
- new - **Interface** --- Display plug-in action details in the plug-in details view on iOS and macOS.
- new - **API** --- Added support for a `description` metadata value on `PlugIn.Action` and exposed it in the scripting API.
- new - **API** --- Added `label` related properties to `PlugIn.Action`.
- updated - **API Reference** --- Fixed some styling where pieces of documentation would appear black in the dark appearance.
- updated - **API Reference** --- Improve sorting and display name format in the API reference sidebar, based on the selected organization type.
- updated - **macOS API Reference** --- Fix the appearance of the organization button in the documentation sidebar when running in the dark appearance.

### April 8, 2020 ###
- updated - **macOS Console** --- Improve layout and selection of input and output rows in the console.

### April 7, 2020 ###
- updated - **Documents** --- The `makeNew` and `makeNewAndShow` functions return a `Promise` in addition to having an optional callback `Function`.

### March 30, 2020 ###
- updated - **iOS** --- Allow running nested Alerts and Forms.

### March 27, 2020 ###
- updated - **iOS Plug-ins** --- Allow specifying where to install plug-ins when one is shared to the app.

### March 26, 2020 ###
- updated - **macOS Plug-ins** --- In the Plug-ins sheet, allow deleting plug-ins with a swipe.
- updated - **macOS Plug-ins** --- In the Plug-ins window, allow deleting plug-ins with the delete key or context menu.

### March 25, 2020 ###
- updated - **macOS Plug-ins** --- Added a `+` button on the plug-in location rows to allow adding plug-ins directly to specific locations.
- updated - **macOS Plug-ins** --- The new plug-in action sheet allows picking which plug-in location should be used to save the new plug-in.

### March 24, 2020 ###
- updated - **macOS Plug-ins** --- The new plug-in action template no longer polutes the top-level namespace with a `_` symbol.

### March 23, 2020 ###
- updated - **macOS Plug-ins** --- Renamed the `Add...` and `Remove` buttons to `Add Folder...` and `Disconnect Folder`.
- updated - **macOS Plug-ins** --- Can drag and drop plug-ins between search locations, as well as drag new plug-ins into search locations.

### March 20, 2020 ###
- new - **Plug-ins** --- Added a default search location in the app's default iCloud container for iCloud-enabled applications.
- new - **iOS Plug-in Locations** --- Added support for dragging plug-ins between folders on iOS.

### March 19, 2020 ###
- updated - **iOS Form** --- Automatically place keyboard focus in the first form field that can accept it.
- fixed - **Form** --- Fixed support for the initial selected value in `Form.Field.Option` instances to support more types of values.

### March 18, 2020 ###
- updated - **Script Preview** --- Adjusted layout of the script confirmation sheet to fit iPhone X appropriately.
- updated - **iOS Form** --- Added keyboard shortcuts, currently command-return and command-period to confirm and cancel the form.

### January 21, 2020 ###
- new - **URL Scheme** --- You can now use `URL.currentAppScheme` to get the URL scheme for the current app. (This is useful for generating URLs like the _bypass previews_ example in the previous note.)

### January 19, 2020 ###
- new - **Bypass Script Previews** --- The new `OJSBypassPreviews` preference will let you bypass the script preview/authentication prompt until a cutoff date is reached. For example, use a URL like `omniapp:///change-preference?OJSBypassPreviews=2h` to bypass previews for the next two hours.
- fixed - **Form Validation on iOS** --- Fixed a bug on iOS where forms would initially present as valid despite the initial state being invalid.

### January 9, 2020 ###
- updated - **Crash** --- Fix crash if the argument to `URL.tellFunction` is not serializable as JSON.

### October 16, 2019 ###
- new - **API** --- Added `URL.open()`, which asks the system to open a URL.

### September 30, 2019 ###
- new - **iPadOS 13 Support** --- Forms, file pickers, and alerts now support multiple windows on iPadOS 13.
- new - **API** --- Added `URL.find()`, an asynchronous API which scans a directory URL for files of the given types.
- fixed - **Integration** --- Fixed a URL encoding bug in `tellScript` when the source contained `&amp;`.

### June 20, 2019 ###
- updated - **API Reference** --- Updated the API Reference content area to show the proper entries based on the sidebar selection and selected organization method.
- updated - **API Reference** --- Updated the macOS API Reference to support configurable organization and to only show the base name of each entry.

### June 19, 2019 ###
- updated - **API Reference** --- On iOS, only display the base name of the type in the API reference sidebar. The full path to the type is still shown in the documentation pane.
- updated - **API Reference** --- On iOS, added a bar item to control the organization in the API Reference, with options for inheritance, containment, or flat.
- updated - **API Reference** --- Adjust the style sheet to allow function signatures to wrap. This avoids inconsistent default scaling when switching sections in the API reference on iOS.

### June 18, 2019 ###
- updated - **Code Completion** --- Fixed a case where the code completion window could show a horizontal scroller.

### June 14, 2019 ###
- updated - **File Wrappers** --- The synchronous `fileWrapper()` function is deprecated. Instead, `makeFileWrapper()` should be used, which returns a `Promise`.

### June 10, 2019 ###
- updated - **Mac** --- The plug-in locations interface has moved from the application preferences to the Automation &gt; Plug-Ins… menu.

### April 31, 2019 ###
- new - **API** --- Added `FileSaver` for running the system interface for saving a file.
- new - **API** --- Added `FileWrapper.withChildren()` for creating directory-based file wrappers.

### April 30, 2019 ###
- new - **API** --- Added a `URL.tellFunction()` which takes a function to invoke in the other app.

### April 25, 2019 ###
- updated - **Mac Preferences** --- The document-based applications no longer search extra folders added in the Resource Browser for plug-ins. Instead, there is a Plug-ins preference pane to configure those search locations independently of locations for templates and stencils.
- updated - **Mac Console** --- Toolbar actions on the console window will forward to the front document window.
- updated - **Plug-in Loading** --- Fixed a regression where plug-ins would not be reloaded automatically after being edited .

### April 17, 2019 ###
- new - **iOS Keyboard Shortcuts** --- Added support for binding plug-in actions to key commands on iOS.

### April 2, 2019 ###
- updated - **Menu** --- Don't display a menu entry for a plug-in with zero actions.
- updated - **Actions** --- Single-file library plug-ins can be called from an OmniJS URL.

### April 1, 2019 ###
- new - **API** --- Added a `message` property on `FilePicker`. On macOS this is shown as part of the system open panel. The system iOS document picker has no support for a message.
- new - **API** --- Added `DateComponents` constructor and several functions on `Calendar` for performing date math.
- new - **iOS** --- The automation menu now has a "Plug-Ins" option which shows descriptions of plug-ins and allows adding external linked folders of plug-ins (say, in iCloud), as well as allowing deletion of plug-ins that are installed on the device.

### March 13, 2019 ###
- updated - **API** --- `Form.Field` objects with no display name no longer show a label when the form is presented.

### January 7, 2019 ###
- new - **API** --- Added convenience accessors on the `FileType` constructor for common file types.
- new - **API** --- Added support for constructing `FileType` instances with an identifier (`new FileType("com.example.mytype")`).
- new - **API** --- Added `FileType.conforms()` function, to check if a given type is a specific instance of a more general type.

### December 6, 2018 ###
- new - **API** --- Added a `Form` constructor, and initial set of `Field` constructors. These may be used to construct simple prompts to request input from the user.
- updated - **Mac Console** --- The macOS console window now has a toolbar with some default options. Notably, there is an `Add Action` toolbar item that creates a new standalone `.omnijs` script, saves it, and opens it in a selected editor (optionally adding it to the toolbar too). This can be a useful way to prototype new script actions.
- updated - **Mac Toolbar** --- When you save edits to a plug-in in some external editor, and one of its actions is on a toolbar, the action will glow briefly when it has been reloaded. 

### November 27, 2018 ###
- new - **API** --- Added a `FilePicker` constructor, which may be instantiated and shown to allow selection of files and folders by the user. Results are yielded via a `Promise`.
- updated - **API** --- `Alert.show` now returns a `Promise`. The previous `callback` argument is still supported for now, but using the `Promise` should be preferred.


### November 15, 2018 ###
- updated - **Script Invocation** --- For applications that support incoming script invocation via URLs, if invoked script evaluates to a `Promise` instance, the `x-callback` reply message will wait until the promise is resolved, using its success value or error.

### November 8, 2018 ###
- new - **API** --- The macOS and iOS API reference areas allow exporting the documentation as Markdown.

### June 22, 2018 ###
- new - **Console** --- The macOS and iOS console input areas now have code completion suggestions.

### May 23, 2018 ###
- updated - **Console** --- Enumeration-type objects (for example, `ColorSpace`) will now include their name when evaluated in the console. For example, `ColorSpace.RBG` will emit `[object ColorSpace: RGB]` in the console.
- updated - **Undo** --- Script actions that make edits will have their menu or toolbar item label set as the undo action name.
- updated - **Alert** --- Updated the documentation for `Alert`.
- updated - **Alert** --- Make the `callback` function passed to `Alert.show()` optional.
- updated - **Alert** --- On macOS, `Alert` instances are shown as a modal sheet on a document window, if possible, instead of as an app-wide modal alert.
- new - **New** --- Added release notes support.
