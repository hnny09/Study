<h2 id="recent">Recent Changes</h2>

<!-- Put items in the same order as the key: danger, new, updated, fixed -->  

### April 22, 2020 ###
- new - **New** &mdash; Added `Formatter` class and related types from OmniOutliner.

### January 7, 2019 ###
- new - **New** &mdash; Added `Canvas.combine` function and `ShapeCombination` type to allow performing shape combinations from scripts.
